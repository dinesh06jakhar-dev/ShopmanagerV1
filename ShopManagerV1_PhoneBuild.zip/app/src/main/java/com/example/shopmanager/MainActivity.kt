package com.example.shopmanager

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.room.Room
import com.example.shopmanager.data.AppDatabase
import com.example.shopmanager.data.Product
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class ShopViewModel(private val db: AppDatabase) : ViewModel() {
    val products = db.productDao().observeAll()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun addProduct(name: String, stock: Int, buy: Double, sell: Double, low: Int) {
        viewModelScope.launch {
            db.productDao().insert(
                Product(
                    name = name.trim(),
                    stock = stock.coerceAtLeast(0),
                    purchasePricePaise = (buy * 100).toLong(),
                    sellingPricePaise = (sell * 100).toLong(),
                    lowStockLimit = low.coerceAtLeast(0)
                )
            )
        }
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val db = Room.databaseBuilder(
            applicationContext,
            AppDatabase::class.java,
            "shop_manager.db"
        ).build()
        val vm = ShopViewModel(db)

        setContent {
            ShopManagerApp(vm)
        }
    }
}

@Composable
fun ShopManagerApp(vm: ShopViewModel) {
    val products by vm.products.collectAsState()
    var tab by remember { mutableIntStateOf(0) }

    MaterialTheme {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Text("Shop Manager", fontWeight = FontWeight.Bold)
                    }
                )
            },
            bottomBar = {
                NavigationBar {
                    val items = listOf(
                        Icons.Default.Home to "Home",
                        Icons.Default.Inventory to "Stock",
                        Icons.Default.Receipt to "Sales",
                        Icons.Default.BarChart to "Reports"
                    )
                    items.forEachIndexed { index, item ->
                        NavigationBarItem(
                            selected = tab == index,
                            onClick = { tab = index },
                            icon = { Icon(item.first, contentDescription = item.second) },
                            label = { Text(item.second) }
                        )
                    }
                }
            }
        ) { padding ->
            when (tab) {
                0 -> Dashboard(padding, products)
                1 -> StockScreen(padding, products, vm)
                2 -> SalesScreen(padding)
                else -> ReportsScreen(padding, products)
            }
        }
    }
}

@Composable
fun Dashboard(padding: PaddingValues, products: List<Product>) {
    Column(
        Modifier.padding(padding).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Today's Dashboard", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatCard("Sales", "₹0", Modifier.weight(1f))
            StatCard("Profit", "₹0", Modifier.weight(1f))
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatCard("Products", products.size.toString(), Modifier.weight(1f))
            StatCard("Low Stock", products.count { it.stock <= it.lowStockLimit }.toString(), Modifier.weight(1f))
        }
        Button(onClick = {}, Modifier.fillMaxWidth().height(52.dp)) {
            Icon(Icons.Default.Mic, null)
            Spacer(Modifier.width(8.dp))
            Text("Voice Entry")
        }
        OutlinedButton(onClick = {}, Modifier.fillMaxWidth().height(52.dp)) {
            Icon(Icons.Default.QrCodeScanner, null)
            Spacer(Modifier.width(8.dp))
            Text("Scan Barcode")
        }
    }
}

@Composable
fun StatCard(title: String, value: String, modifier: Modifier) {
    Card(modifier) {
        Column(Modifier.padding(16.dp)) {
            Text(title, style = MaterialTheme.typography.labelLarge)
            Text(value, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun StockScreen(
    padding: PaddingValues,
    products: List<Product>,
    vm: ShopViewModel
) {
    var showAdd by remember { mutableStateOf(false) }

    Column(Modifier.padding(padding).padding(16.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(
                "Products & Stock",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f)
            )
            Button(onClick = { showAdd = true }) { Text("Add") }
        }
        Spacer(Modifier.height(12.dp))
        if (products.isEmpty()) {
            Text("No products yet. Tap Add to create your first product.")
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(products, key = { it.id }) { p ->
                    val profit = p.sellingPricePaise - p.purchasePricePaise
                    Card(Modifier.fillMaxWidth()) {
                        Row(
                            Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(Modifier.weight(1f)) {
                                Text(p.name, fontWeight = FontWeight.Bold)
                                Text("Stock: ${p.stock}")
                                Text("Buy: ₹${p.purchasePricePaise / 100.0}  Sell: ₹${p.sellingPricePaise / 100.0}")
                                if (p.stock <= p.lowStockLimit) {
                                    Text("LOW STOCK", color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.Bold)
                                }
                            }
                            Text("Profit ₹${profit / 100.0}", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }

    if (showAdd) {
        AddProductDialog(
            onDismiss = { showAdd = false },
            onSave = { name, stock, buy, sell, low ->
                vm.addProduct(name, stock, buy, sell, low)
                showAdd = false
            }
        )
    }
}

@Composable
fun AddProductDialog(
    onDismiss: () -> Unit,
    onSave: (String, Int, Double, Double, Int) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var stock by remember { mutableStateOf("") }
    var buy by remember { mutableStateOf("") }
    var sell by remember { mutableStateOf("") }
    var low by remember { mutableStateOf("10") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add Product") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("Product name") }, singleLine = true)
                OutlinedTextField(stock, { stock = it }, label = { Text("Opening stock") }, singleLine = true)
                OutlinedTextField(buy, { buy = it }, label = { Text("Purchase price ₹") }, singleLine = true)
                OutlinedTextField(sell, { sell = it }, label = { Text("Selling price ₹") }, singleLine = true)
                OutlinedTextField(low, { low = it }, label = { Text("Low stock limit") }, singleLine = true)
            }
        },
        confirmButton = {
            Button(onClick = {
                if (name.isNotBlank()) {
                    onSave(
                        name,
                        stock.toIntOrNull() ?: 0,
                        buy.toDoubleOrNull() ?: 0.0,
                        sell.toDoubleOrNull() ?: 0.0,
                        low.toIntOrNull() ?: 10
                    )
                }
            }) { Text("Save") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@Composable
fun SalesScreen(padding: PaddingValues) {
    Column(Modifier.padding(padding).padding(16.dp)) {
        Text("Sales & Billing", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(20.dp))
        Text("Billing module will be added in Phase 2.")
        Spacer(Modifier.height(20.dp))
        Button(onClick = {}, Modifier.fillMaxWidth()) { Text("New Sale") }
    }
}

@Composable
fun ReportsScreen(padding: PaddingValues, products: List<Product>) {
    Column(Modifier.padding(padding).padding(16.dp)) {
        Text("Reports", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(16.dp))
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Today's Report", fontWeight = FontWeight.Bold)
                Text("Sales: ₹0")
                Text("Purchases: ₹0")
                Text("Profit: ₹0")
                Text("Products: ${products.size}")
            }
        }
    }
}
