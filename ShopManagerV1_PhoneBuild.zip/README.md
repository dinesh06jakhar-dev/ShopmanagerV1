# ShopManager V1

Phone-buildable Android project for the first phase of the shop management app.

Phase 1:
- Dashboard
- Product management
- Offline Room database
- Stock values
- Purchase/selling price
- Low-stock indicator

Planned next phases:
- Billing and sales
- Barcode scanner
- Voice entry
- Reports
- Daily opening/closing
- Firebase backup
