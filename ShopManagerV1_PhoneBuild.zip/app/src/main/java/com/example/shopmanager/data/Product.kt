package com.example.shopmanager.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "products")
data class Product(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val stock: Int,
    val purchasePricePaise: Long,
    val sellingPricePaise: Long,
    val lowStockLimit: Int = 10,
    val barcode: String? = null
)
